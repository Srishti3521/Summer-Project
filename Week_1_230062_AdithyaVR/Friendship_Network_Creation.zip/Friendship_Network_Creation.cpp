#include<bits/stdc++.h>
#include <climits>
using namespace std;
const int N = 1000;  // Number of students

// Graph is constructed as an adjacency list: node -> (neighbour, weight)
vector<pair<int, int>> adj[N];

// Attributes of students
vector<int> Gender(N);
vector<int> student_dept(N);
vector<int> Habit(N);
vector<int> Hostel(N);
vector<int> Nature(N);

// Random number generation function
int rand_range(int a, int b) {
    return a + rand() % (b - a + 1);
}

// Main function for generating friendships
void generate_friendships(){

    //Assigning attributes
    for(int i = 0; i < N; ++i) {
        Gender[i] = rand_range(1, 2); //1-Female, 2-Male
        if(Gender[i]==1){
            Hostel[i] = rand_range(1, 3);
        }
        else{
            Hostel[i] = rand_range(4, 6);
        } 
        student_dept[i] = rand_range(1, 10); // 10 departments
        Nature[i] = rand_range(1, 3); // 1,2,3-Introvert,Ambivert,Extrovert
        Habit[i] = rand_range(1, 2); // 1 for no drinking and smoking, 2 for alternate
    }
       
    // Friendships modelled as edges
    for (int i = 0; i < N; ++i) {
        int friends_to_add = rand_range(5, 10); // Number of possible friends 

        set<int> already_friends;

        for (int j = 0; j < friends_to_add; ++j){
            int target;
            do {
                target = rand_range(0, N - 1);
            } while (target == i || already_friends.count(target));

            // Friendships generated based on similarity
            int similarity_score=0;
            if(Gender[i]==Gender[target]){
                similarity_score+=5;
            }
            else{
                similarity_score+=2;
            }

            if(Hostel[i]==Hostel[target]){
                similarity_score+=10;
            }
            else{
                similarity_score+=3;
            }

            if(student_dept[i]==student_dept[target]){
                similarity_score+=5;
            }

            else{
                similarity_score+=1;
            }

            if(Habit[i]==Habit[target]){
                similarity_score+=5;
            }
            else{
                similarity_score+=1;
            }

            if(Nature[target]==2 && Nature[i]==2){
                similarity_score+=9;
            }
            else if(Nature[target]==1 || Nature[i]==1){
                similarity_score+=6;
            }
            else if((Nature[target]==0 && Nature[i]==0)){
                similarity_score+=3;
            }
            else{
                similarity_score+=4;
            }
            if (rand_range(0,85) < similarity_score) {
                int weight = rand_range(1, 10); // 1 = strong, 10 = weak
                adj[i].emplace_back(target, weight);
                adj[target].emplace_back(i, weight);
                already_friends.insert(target);
            }
        }
    }
}

