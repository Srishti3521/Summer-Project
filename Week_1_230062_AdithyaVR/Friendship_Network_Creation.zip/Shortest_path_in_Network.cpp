vector<pair<int, int>> friendship_pairs;

vector<int> Dijkstra(int node1,int node2){
    int dist[N];
    vector<int> parent(N, -1);
    for (int i=0;i<N;i++){
        if(i==node1){
            dist[i]=0;
        }
        else{
            dist[i]=INT_MAX;
        }
    }
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0,node1});
    while(!pq.empty()){
        int weight = pq.top().first; 
        int curr_node = pq.top().second;
        pq.pop();
        for(auto &it:adj[curr_node]){
            if((weight + it.second)<dist[it.first]){
                dist[it.first]=weight + it.second;
                parent[it.first] = curr_node;//storing the node that found the best current node, helps in reconstruction
                pq.push({(weight + it.second),it.first});
            }
        }
    }

    //Path Reconstruction
    vector<int> path;
    for (int at = node2; at != -1; at = parent[at]) {
        path.push_back(at);
    }
    reverse(path.begin(), path.end());
    if (path.size() == 1 && path[0] != node1)
        return {};
    return path;


}

int social_heuristic(int u, int v) {
    int score = 0;

    // Using the same properties that was taken into account for creating friendships, just a little less buff for matches to keep the heuristic score down
    if (Gender[u] != Gender[v])
        score += 2;
    else
        score += 1;

    // Different hostels
    if (Hostel[u] != Hostel[v])
        score += 2;
    else
        score += 1;

    // Department mismatch
    if (student_dept[u] != student_dept[v])
        score += 3;
    else
        score += 1;

    // Habit mismatch
    if (Habit[u] != Habit[v])
        score += 2;
    else
        score += 1;

    // Nature
    if (Nature[u] == 2 && Nature[v] == 2)
        score += 2;  // ambiverts connect reasonably well
    else if (Nature[u] == 1 || Nature[v] == 1)
        score += 3;  // one introvert: moderately high effort
    else
        score += 1;  // extrovert: easier effort

    return score;  // Lower = easier social connection
}
vector<int> astar(int src, int dst){
    vector<int> dist(N, INT_MAX), parent(N, -1);
    dist[src] = 0;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
    pq.emplace(0 + social_heuristic(src, dst), src);

    while (!pq.empty()) {
        auto [_, u] = pq.top(); pq.pop();
        if (u == dst) break;

        for (auto [v, w] : adj[u]) {
            if (dist[v] > dist[u] + w) {
                dist[v] = dist[u] + w;
                parent[v] = u;
                pq.emplace(dist[v] + social_heuristic(v, dst), v);
            }
        }
    }

    vector<int> path;
    for (int at = dst; at != -1; at = parent[at])
        path.push_back(at);
    reverse(path.begin(), path.end());
    return path;
}