#include<bits/stdc++.h>
#include <climits>
using namespace std;
const int N = 1000;  // Number of students

// Graph is constructed as an adjacency list: node -> (neighbour, weight)
vector<pair<int, int>> adj[N];

// Attributes of students
vector<int> Gender(N);
vector<int> student_dept(N);
vector<int> Habit(N);
vector<int> Hostel(N);
vector<int> Nature(N);

// Random number generation function
int rand_range(int a, int b) {
    return a + rand() % (b - a + 1);
}

// Main function for generating friendships
void generate_friendships(){

    //Assigning attributes
    for(int i = 0; i < N; ++i) {
        Gender[i] = rand_range(1, 2); //1-Female, 2-Male
        if(Gender[i]==1){
            Hostel[i] = rand_range(1, 3);
        }
        else{
            Hostel[i] = rand_range(4, 6);
        } 
        student_dept[i] = rand_range(1, 10); // 10 departments
        Nature[i] = rand_range(1, 3); // 1,2,3-Introvert,Ambivert,Extrovert
        Habit[i] = rand_range(1, 2); // 1 for no drinking and smoking, 2 for alternate
    }
       
    // Friendships modelled as edges
    for (int i = 0; i < N; ++i) {
        int friends_to_add = rand_range(5, 10); // Number of possible friends 

        set<int> already_friends;

        for (int j = 0; j < friends_to_add; ++j){
            int target;
            do {
                target = rand_range(0, N - 1);
            } while (target == i || already_friends.count(target));

            // Friendships generated based on similarity
            int similarity_score=0;
            if(Gender[i]==Gender[target]){
                similarity_score+=5;
            }
            else{
                similarity_score+=2;
            }

            if(Hostel[i]==Hostel[target]){
                similarity_score+=10;
            }
            else{
                similarity_score+=3;
            }

            if(student_dept[i]==student_dept[target]){
                similarity_score+=5;
            }

            else{
                similarity_score+=1;
            }

            if(Habit[i]==Habit[target]){
                similarity_score+=5;
            }
            else{
                similarity_score+=1;
            }

            if(Nature[target]==2 && Nature[i]==2){
                similarity_score+=9;
            }
            else if(Nature[target]==1 || Nature[i]==1){
                similarity_score+=6;
            }
            else if((Nature[target]==0 && Nature[i]==0)){
                similarity_score+=3;
            }
            else{
                similarity_score+=4;
            }
            if (rand_range(0,85) < similarity_score) {
                int weight = rand_range(1, 10); // 1 = strong, 10 = weak
                adj[i].emplace_back(target, weight);
                adj[target].emplace_back(i, weight);
                already_friends.insert(target);
            }
        }
    }
}

vector<bool> visited;// To ensure that a node(Student) has been visited during traversal

//Breadth First Search
int bfs(int start) {
    queue<int> q;
    q.push(start);
    visited[start] = true;
    int size = 1;

    while (!q.empty()) {
        int node = q.front(); q.pop();
        for (auto &it: adj[node]) {
            if (!visited[it.first]) {
                visited[it.first] = true;
                q.push(it.first);
                size++;
            }
        }
    }

    return size;
}

//Function that evaluates the number of distinct groups, returns the size of the biggest and smallest group using bfs traversal
void analyze_groups_bfs(){
    int num_groups = 0;
    int min_size = N, max_size = 0;
    visited.assign(N, false); // Resetting to ensure no interference during multiple calls

    for (int i = 1; i < N; ++i){
        if (!visited[i]) {
            int group_size = bfs(i);
            num_groups++;
            min_size = min(min_size, group_size);
            max_size = max(max_size, group_size);
        }
    }
    cout << "Friend Groups: " << num_groups << "\n";
    cout << "Smallest group size: " << min_size << "\n";
    cout << "Largest group size: " << max_size << "\n";
}
vector<pair<int, int>> friendship_pairs;

vector<int> Dijkstra(int node1,int node2){
    int dist[N];
    vector<int> parent(N, -1);
    for (int i=0;i<N;i++){
        if(i==node1){
            dist[i]=0;
        }
        else{
            dist[i]=INT_MAX;
        }
    }
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0,node1});
    while(!pq.empty()){
        int weight = pq.top().first; 
        int curr_node = pq.top().second;
        pq.pop();
        for(auto &it:adj[curr_node]){
            if((weight + it.second)<dist[it.first]){
                dist[it.first]=weight + it.second;
                parent[it.first] = curr_node;//storing the node that found the best current node, helps in reconstruction
                pq.push({(weight + it.second),it.first});
            }
        }
    }

    //Path Reconstruction
    vector<int> path;
    for (int at = node2; at != -1; at = parent[at]) {
        path.push_back(at);
    }
    reverse(path.begin(), path.end());
    if (path.size() == 1 && path[0] != node1)
        return {};
    return path;


}

int social_heuristic(int u, int v) {
    int score = 0;

    // Using the same properties that was taken into account for creating friendships, just a little less buff for matches to keep the heuristic score down
    if (Gender[u] != Gender[v])
        score += 2;
    else
        score += 1;

    // Different hostels
    if (Hostel[u] != Hostel[v])
        score += 2;
    else
        score += 1;

    // Department mismatch
    if (student_dept[u] != student_dept[v])
        score += 3;
    else
        score += 1;

    // Habit mismatch
    if (Habit[u] != Habit[v])
        score += 2;
    else
        score += 1;

    // Nature
    if (Nature[u] == 2 && Nature[v] == 2)
        score += 2;  // ambiverts connect reasonably well
    else if (Nature[u] == 1 || Nature[v] == 1)
        score += 3;  // one introvert: moderately high effort
    else
        score += 1;  // extrovert: easier effort

    return score;  // Lower = easier social connection
}
vector<int> astar(int src, int dst){
    vector<int> dist(N, INT_MAX), parent(N, -1);
    dist[src] = 0;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
    pq.emplace(0 + social_heuristic(src, dst), src);

    while (!pq.empty()) {
        auto [_, u] = pq.top(); pq.pop();
        if (u == dst) break;

        for (auto [v, w] : adj[u]) {
            if (dist[v] > dist[u] + w) {
                dist[v] = dist[u] + w;
                parent[v] = u;
                pq.emplace(dist[v] + social_heuristic(v, dst), v);
            }
        }
    }

    vector<int> path;
    for (int at = dst; at != -1; at = parent[at])
        path.push_back(at);
    reverse(path.begin(), path.end());
    return path;
}
int main(){
    srand(0);//Reproducibility
    generate_friendships();
    analyze_groups_bfs();
    for(int i=0; i<5 ;i++){
        int x=rand_range(0,1000);
        int y=x;
        while(y==x){
            y=rand_range(0,1000);
        }
        friendship_pairs.push_back({x,y});
    }
    for(auto &it: friendship_pairs){
        vector<int> shortest_path= Dijkstra(it.first,it.second);
        if(shortest_path.empty()){
            cout << "No path between " << it.first << " and " << it.second << '\n';
        }
        else{
            cout << "Minimum effort path(Dijkstra) between " << it.first << " and " << it.second << " is:" << '\n';
            for(auto j: shortest_path){
                cout << j << ' ';
            }
            cout << '\n';
        }
    }
    cout << '\n';
    for(auto &it: friendship_pairs){
        vector<int> shortest_path= astar(it.first,it.second);
        if(shortest_path.empty()){
            cout << "No path between " << it.first << " and " << it.second << '\n';
        }
        else{
            cout << "Minimum effort path(A*) between " << it.first << " and " << it.second << " is:" << '\n';
            for(auto j: shortest_path){
                cout << j << ' ';
            }
            cout << '\n';
        }
    }
}