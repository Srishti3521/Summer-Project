vector<bool> visited;// To ensure that a node(Student) has been visited during traversal

//Breadth First Search
int bfs(int start) {
    queue<int> q;
    q.push(start);
    visited[start] = true;
    int size = 1;

    while (!q.empty()) {
        int node = q.front(); q.pop();
        for (auto &it: adj[node]) {
            if (!visited[it.first]) {
                visited[it.first] = true;
                q.push(it.first);
                size++;
            }
        }
    }

    return size;
}

//Function that evaluates the number of distinct groups, returns the size of the biggest and smallest group using bfs traversal
void analyze_groups_bfs(){
    int num_groups = 0;
    int min_size = N, max_size = 0;
    visited.assign(N, false); // Resetting to ensure no interference during multiple calls

    for (int i = 1; i < N; ++i){
        if (!visited[i]) {
            int group_size = bfs(i);
            num_groups++;
            min_size = min(min_size, group_size);
            max_size = max(max_size, group_size);
        }
    }
    cout << "Friend Groups: " << num_groups << "\n";
    cout << "Smallest group size: " << min_size << "\n";
    cout << "Largest group size: " << max_size << "\n";
}